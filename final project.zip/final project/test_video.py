import cv2
import os

def test_video(video_path):
    
    if not os.path.exists(video_path):
        print(f"Error: Video file not found at {video_path}")
        return
        
    
    video = cv2.VideoCapture(video_path)
    print(f"Video opened successfully: {video.isOpened()}")
    
    if video.isOpened():
        
        ret, frame = video.read()
        print(f"Frame read successfully: {ret}")
        
        
        fps = video.get(cv2.CAP_PROP_FPS)
        frame_count = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
        
        print(f"\nVideo Properties:")
        print(f"FPS: {fps}")
        print(f"Total Frames: {frame_count}")
        print(f"Resolution: {width}x{height}")
        
       
        video.release()
    else:
        print("Failed to open video file")

if __name__ == "__main__":
    
    video_path = "C:/Users/Saraswati/OneDrive/Desktop/dashboard_ecodrishti/uploads/Olle Knutson-new-york-city-streets-708482-filmsupply (1).mp4"
    test_video(video_path)