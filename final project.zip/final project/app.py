from flask import Flask, render_template, Response, jsonify, request
import cv2
import google.generativeai as genai
import PIL.Image
import io
import numpy as np
import threading
import time
from queue import Queue
from datetime import datetime
import json
from flask_socketio import SocketIO
import base64
import os
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
socketio = SocketIO(app)
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class GarbageDetectionSystem:
    def __init__(self, api_key):
        try:
            genai.configure(api_key=api_key)
            # Updated to use gemini-1.5-flash model
            self.model = genai.GenerativeModel('gemini-1.5-flash')
            logger.info("Gemini API initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini API: {str(e)}")
            raise

        self.video_path = None
        self.is_running = False
        self.frame_interval = 2.0
        self.last_processed_time = 0
        self.detections = []
        self.current_frame = None
        self.lock = threading.Lock()
        self.video_capture = None

    def set_video(self, video_path):
        try:
            logger.info(f"Setting video: {video_path}")
            self.video_path = video_path
            if self.video_capture:
                self.video_capture.release()
            self.video_capture = cv2.VideoCapture(video_path)
            
            if not self.video_capture.isOpened():
                logger.error(f"Failed to open video file: {video_path}")
                raise Exception("Failed to open video file")
                
            fps = self.video_capture.get(cv2.CAP_PROP_FPS)
            frame_count = int(self.video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
            logger.info(f"Video loaded successfully. FPS: {fps}, Frame count: {frame_count}")
            
        except Exception as e:
            logger.error(f"Error in set_video: {str(e)}")
            raise
        
    def analyze_frame(self, frame):
        try:
            logger.debug("Starting frame analysis")
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            pil_image = PIL.Image.fromarray(rgb_frame)
            
            prompt = """
            Please analyze this image frame and identify any garbage or waste:
            - Is there visible garbage? (yes/no)
            - Where is it located in the frame?
            - What is the approximate size? (small/medium/large)
            - What is the urgency level for cleanup? (low/medium/high)
            Provide a concise, structured response.
            """
            
            logger.debug("Sending frame to Gemini API")
            # Updated response handling for gemini-1.5-flash
            response = self.model.generate_content([prompt, pil_image], stream=False)
            
            # New response handling
            try:
                response_text = response.text  # Use .text directly instead of accessing candidates
                logger.debug(f"Received response from Gemini API: {response_text}")
                
                detection = {
                    'id': len(self.detections) + 1,
                    'timestamp': datetime.now().isoformat(),
                    'location': 'Frame center',
                    'size': 'medium',
                    'urgency': 'high',
                    'status': 'pending',
                    'raw_response': response_text
                }
                
                # Parse the response text to extract structured information
                # You might want to add more sophisticated parsing based on your needs
                if response_text:
                    detection['raw_response'] = response_text
                    
                    # Simple parsing example
                    response_lower = response_text.lower()
                    if 'garbage' in response_lower and 'yes' in response_lower:
                        # Extract location if mentioned
                        if 'located' in response_lower:
                            try:
                                location_start = response_lower.index('located') + 7
                                location_end = response_lower.find('.', location_start)
                                if location_end != -1:
                                    detection['location'] = response_text[location_start:location_end].strip()
                            except ValueError:
                                pass
                        
                        # Extract size if mentioned
                        for size in ['small', 'medium', 'large']:
                            if size in response_lower:
                                detection['size'] = size
                                break
                        
                        # Extract urgency if mentioned
                        for urgency in ['low', 'medium', 'high']:
                            if urgency in response_lower:
                                detection['urgency'] = urgency
                                break
                        
                        logger.info(f"Garbage detected in frame: {detection}")
                        with self.lock:
                            self.detections.append(detection)
                            socketio.emit('new_detection', detection)
                
                return detection
                
            except Exception as parsing_error:
                logger.error(f"Error parsing Gemini response: {str(parsing_error)}")
                return None
                
        except Exception as e:
            logger.error(f"Error in analyze_frame: {str(e)}")
            return None

    # Rest of the class implementation remains the same
    def generate_frames(self):
        if not self.video_capture:
            logger.warning("No video capture object available - waiting for video upload")
            blank_frame = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(blank_frame, 'Waiting for video...', (150, 240),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            ret, buffer = cv2.imencode('.jpg', blank_frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            return

        while self.is_running:
            try:
                success, frame = self.video_capture.read()
                if not success:
                    logger.debug("End of video reached, resetting to start")
                    self.video_capture.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue

                current_time = time.time()
                
                if current_time - self.last_processed_time >= self.frame_interval:
                    threading.Thread(target=self.analyze_frame, args=(frame.copy(),)).start()
                    self.last_processed_time = current_time

                cv2.putText(frame, 'Processing...', (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                ret, buffer = cv2.imencode('.jpg', frame)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

            except Exception as e:
                logger.error(f"Error in generate_frames: {str(e)}")
                time.sleep(0.1)

    def start(self):
        logger.info("Starting detection system")
        self.is_running = True

    def stop(self):
        logger.info("Stopping detection system")
        self.is_running = False
        if self.video_capture:
            self.video_capture.release()

# Initialize the detection system with your API key
detection_system = GarbageDetectionSystem(api_key='AIzaSyCBHPyJa-abDYRPjOjU9YbEZnwBTX3wn8s')
logger.info("Detection system initialized successfully")

# The rest of your Flask routes remain the same

@app.route('/')
def index():
    """Main page with video feed and detection log"""
    return render_template('index.html')

@app.route('/upload_video', methods=['POST'])
def upload_video():
    """Handle video file uploads"""
    try:
        if 'video' not in request.files:
            logger.error("No video file in request")
            return jsonify({'error': 'No video file'}), 400
            
        file = request.files['video']
        if file.filename == '':
            logger.error("Empty filename")
            return jsonify({'error': 'No selected file'}), 400
            
        if not allowed_file(file.filename):
            logger.error(f"Invalid file type: {file.filename}")
            return jsonify({'error': 'Invalid file type'}), 400
            
        filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filename)
        logger.info(f"Video file saved: {filename}")
        
        detection_system.stop()
        detection_system.set_video(filename)
        detection_system.start()
        logger.info("Video processing started")
        
        return jsonify({'success': True})
        
    except Exception as e:
        logger.error(f"Error in upload_video: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/video_feed')
def video_feed():
    """Video streaming route"""
    return Response(detection_system.generate_frames(),
                   mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/get_detections')
def get_detections():
    """Get all detections"""
    with detection_system.lock:
        return jsonify(detection_system.detections)

@app.route('/update_status/<int:detection_id>/<status>')
def update_status(detection_id, status):
    """Update detection status"""
    with detection_system.lock:
        for detection in detection_system.detections:
            if detection['id'] == detection_id:
                detection['status'] = status
                socketio.emit('status_update', {'id': detection_id, 'status': status})
                return jsonify({'success': True})
    return jsonify({'success': False})

@socketio.on('connect')
def handle_connect():
    """Handle socket connection"""
    print('Client connected')

if __name__ == '__main__':
    logger.info("Starting application")
    detection_system.start()
    socketio.run(app, debug=True)